/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-5ccb27be'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "design-lab/assets/micro.js",
    "revision": "166def40721729499842dccd8e4dbcdb"
  }, {
    "url": "design-lab/assets/lab.js",
    "revision": "73bccf8c286de40cb7702ef6191f043e"
  }, {
    "url": "design-lab/assets/audit-data.js",
    "revision": "69a8dee9a376d206da7fa97856a082fe"
  }, {
    "url": "design-lab/assets/app.js",
    "revision": "3e25e327f1231f280b4819e67b5bb473"
  }, {
    "url": "assets/zod-DG_YzbeZ.js",
    "revision": null
  }, {
    "url": "assets/WorkspaceHome-DRL31B-d.js",
    "revision": null
  }, {
    "url": "assets/workbox-window.prod.es5-BBnX5xw4.js",
    "revision": null
  }, {
    "url": "assets/with-selector-C-zHAPnp.js",
    "revision": null
  }, {
    "url": "assets/WinLossAnalysis-DrE0cCBB.js",
    "revision": null
  }, {
    "url": "assets/WhatsAppChatPanel-BuCPeYQh.js",
    "revision": null
  }, {
    "url": "assets/WelcomeScreen-B-Pednit.js",
    "revision": null
  }, {
    "url": "assets/VoiceStudio-C3z1tUpX.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-DPEcNlPA.js",
    "revision": null
  }, {
    "url": "assets/vendor-motion-5oAYxQBe.js",
    "revision": null
  }, {
    "url": "assets/vendor-icons-DxyovQfT.js",
    "revision": null
  }, {
    "url": "assets/vendor-echarts-Bx2E32dG.js",
    "revision": null
  }, {
    "url": "assets/vendor-dnd-CJmPzlCp.js",
    "revision": null
  }, {
    "url": "assets/vanilla-m3Xdu9cz.js",
    "revision": null
  }, {
    "url": "assets/useWorkspace-Di_5Gokz.js",
    "revision": null
  }, {
    "url": "assets/useWhatsAppMessages-B2Mv67Ha.js",
    "revision": null
  }, {
    "url": "assets/useStripeIntegration-BEe-cPKG.js",
    "revision": null
  }, {
    "url": "assets/usePlaybookMatrixData-5BQJN3qv.js",
    "revision": null
  }, {
    "url": "assets/useDatabase-7iKzy78N.js",
    "revision": null
  }, {
    "url": "assets/useActiveRecord-C_TCL6Nq.js",
    "revision": null
  }, {
    "url": "assets/TopicTrainingAcademy-D6vcUZDe.js",
    "revision": null
  }, {
    "url": "assets/Timeline-B5enL7iD.js",
    "revision": null
  }, {
    "url": "assets/Textarea-B7HBNXbC.js",
    "revision": null
  }, {
    "url": "assets/TermsOfUse-DYe1bNiT.js",
    "revision": null
  }, {
    "url": "assets/Team-DYPHcmX2.js",
    "revision": null
  }, {
    "url": "assets/sse-BXC3ACPc.js",
    "revision": null
  }, {
    "url": "assets/Sparkles-CCOLa6gS.js",
    "revision": null
  }, {
    "url": "assets/SocialSellingHub-BL3uZ5b0.js",
    "revision": null
  }, {
    "url": "assets/Settings-uFsEonES.js",
    "revision": null
  }, {
    "url": "assets/Select-CoI2idaA.js",
    "revision": null
  }, {
    "url": "assets/schemas-7E24ltTZ.js",
    "revision": null
  }, {
    "url": "assets/RoleplayHub-Tp91gYXv.js",
    "revision": null
  }, {
    "url": "assets/ResetPasswordScreen-z3nnkwed.js",
    "revision": null
  }, {
    "url": "assets/ReportsHub-BFPlxZd2.js",
    "revision": null
  }, {
    "url": "assets/QualificationMatrixPage-BV60-mKi.js",
    "revision": null
  }, {
    "url": "assets/PublicBookingPage-C2neZ_Hx.js",
    "revision": null
  }, {
    "url": "assets/pt-BR-g-tPW2Ip.js",
    "revision": null
  }, {
    "url": "assets/ProspectingHub-BDmUfjii.js",
    "revision": null
  }, {
    "url": "assets/PropostasList-B7f--x23.js",
    "revision": null
  }, {
    "url": "assets/PrivacyPolicy-Dpru5ceA.js",
    "revision": null
  }, {
    "url": "assets/playbook.schema-Du-qI08a.js",
    "revision": null
  }, {
    "url": "assets/playbook.api-CAD7vEzu.js",
    "revision": null
  }, {
    "url": "assets/Pagination-CzIXXncW.js",
    "revision": null
  }, {
    "url": "assets/PageHeader-C4EXC0Bc.js",
    "revision": null
  }, {
    "url": "assets/OnboardingTour-DN9XlStP.js",
    "revision": null
  }, {
    "url": "assets/ObjectionsMatrixPage-CRUbANmV.js",
    "revision": null
  }, {
    "url": "assets/Notifications-CW5-xw5K.js",
    "revision": null
  }, {
    "url": "assets/ModuleAccessAdmin-DFHwl9B7.js",
    "revision": null
  }, {
    "url": "assets/MesaTratamento-C6DAwHP2.js",
    "revision": null
  }, {
    "url": "assets/LoginScreen-C-jidBaO.js",
    "revision": null
  }, {
    "url": "assets/LinkedinIcon-Co6d3IEy.js",
    "revision": null
  }, {
    "url": "assets/LineChart-COALcFTv.js",
    "revision": null
  }, {
    "url": "assets/Line-B76l8Pv0.js",
    "revision": null
  }, {
    "url": "assets/Legend-DDwkgd_2.js",
    "revision": null
  }, {
    "url": "assets/LeadApprovalDeck-DD574g5d.js",
    "revision": null
  }, {
    "url": "assets/Ldr-aM7bfBSd.js",
    "revision": null
  }, {
    "url": "assets/LandingLoginSplitScreen-DCSXszRo.js",
    "revision": null
  }, {
    "url": "assets/LandingInnovative-Btfqyc5_.js",
    "revision": null
  }, {
    "url": "assets/Label-CEERuPd8.js",
    "revision": null
  }, {
    "url": "assets/KpiCard-CnAWUWio.js",
    "revision": null
  }, {
    "url": "assets/knowledge.api-BjKtfptE.js",
    "revision": null
  }, {
    "url": "assets/JoaoReisDiagnosticHub-D0tRwL4z.js",
    "revision": null
  }, {
    "url": "assets/Isometric3DIcons-D87alurc.js",
    "revision": null
  }, {
    "url": "assets/IntelligenceHub-uRObFRQv.js",
    "revision": null
  }, {
    "url": "assets/Integrations-CQIm_txP.js",
    "revision": null
  }, {
    "url": "assets/index-BFQOZUuj.js",
    "revision": null
  }, {
    "url": "assets/icp-options-BfqUa05_.js",
    "revision": null
  }, {
    "url": "assets/graphicalItemSelectors-DV8tcLHG.js",
    "revision": null
  }, {
    "url": "assets/getRadiusAndStrokeWidthFromDot-B3groL1l.js",
    "revision": null
  }, {
    "url": "assets/GamificationWidget-DHzOjFIU.js",
    "revision": null
  }, {
    "url": "assets/FloatingChatbook-3MzTIOwd.js",
    "revision": null
  }, {
    "url": "assets/exceljs.min-ntJnkKwE.js",
    "revision": null
  }, {
    "url": "assets/ErrorBarContext-tEsYqxZN.js",
    "revision": null
  }, {
    "url": "assets/enumMap-91VCl-q2.js",
    "revision": null
  }, {
    "url": "assets/EntityNotes-BTwJWLUQ.js",
    "revision": null
  }, {
    "url": "assets/EntityAttachments-DuDVE8nC.js",
    "revision": null
  }, {
    "url": "assets/EmptyState-DnuTPFEV.js",
    "revision": null
  }, {
    "url": "assets/EliteCommercialAgentWorkspace-J4nDTWrE.js",
    "revision": null
  }, {
    "url": "assets/Editor-B9QAA7EJ.js",
    "revision": null
  }, {
    "url": "assets/Drawer-CjV75jVx.js",
    "revision": null
  }, {
    "url": "assets/DesignLabPage-DRg38qR5.js",
    "revision": null
  }, {
    "url": "assets/db-CXmeHCDu.js",
    "revision": null
  }, {
    "url": "assets/DailyPlanHub-BJT3jGoy.js",
    "revision": null
  }, {
    "url": "assets/DailyClosingGate-CaEvB-Kc.js",
    "revision": null
  }, {
    "url": "assets/CrmOverview-Dt5jKyWJ.js",
    "revision": null
  }, {
    "url": "assets/CrmBoard-BWlogT48.js",
    "revision": null
  }, {
    "url": "assets/copilotoIa.api-Cpnp80wC.js",
    "revision": null
  }, {
    "url": "assets/ContextualTip-Bg3onCae.js",
    "revision": null
  }, {
    "url": "assets/ContactList-CIBJx4Ie.js",
    "revision": null
  }, {
    "url": "assets/contact-links-DTk6AqjF.js",
    "revision": null
  }, {
    "url": "assets/ConfirmDialog-B9NRODCL.js",
    "revision": null
  }, {
    "url": "assets/confetti.module-C94ZD2ww.js",
    "revision": null
  }, {
    "url": "assets/CompanyList-cuvf0E52.js",
    "revision": null
  }, {
    "url": "assets/CommercialIntelligenceHub-CFX6H65M.js",
    "revision": null
  }, {
    "url": "assets/ChatbookHub-BDXQWFaw.js",
    "revision": null
  }, {
    "url": "assets/chartPalette-C2616I7L.js",
    "revision": null
  }, {
    "url": "assets/ChangePasswordGate-C_NEqsqw.js",
    "revision": null
  }, {
    "url": "assets/CartesianGrid-D6G-vhhR.js",
    "revision": null
  }, {
    "url": "assets/CartesianChart-CQRmKFQv.js",
    "revision": null
  }, {
    "url": "assets/Calendar-Chfb05gb.js",
    "revision": null
  }, {
    "url": "assets/CadenceHub-DCT1OKzD.js",
    "revision": null
  }, {
    "url": "assets/BitrixSyncRulesPanel-fDfQKm3j.js",
    "revision": null
  }, {
    "url": "assets/BitrixGuideHub-3YIRfYnC.js",
    "revision": null
  }, {
    "url": "assets/bitrix.api-CVU-xVv2.js",
    "revision": null
  }, {
    "url": "assets/BirthHubLogo-I0fxwONr.js",
    "revision": null
  }, {
    "url": "assets/Billing-DWUAhAJj.js",
    "revision": null
  }, {
    "url": "assets/Base-D-d4rbEd.js",
    "revision": null
  }, {
    "url": "assets/BarChart-qAGoVaN4.js",
    "revision": null
  }, {
    "url": "assets/Bar-DmQ-E8qf.js",
    "revision": null
  }, {
    "url": "assets/Badge-CD21nVxT.js",
    "revision": null
  }, {
    "url": "assets/Automations-DWOiYLSK.js",
    "revision": null
  }, {
    "url": "assets/AreaChart-DTqGyK7v.js",
    "revision": null
  }, {
    "url": "assets/App-CoewVDf2.js",
    "revision": null
  }, {
    "url": "assets/analytics.api-DkRsBb-s.js",
    "revision": null
  }, {
    "url": "assets/Analytics-Dagg6s8N.js",
    "revision": null
  }, {
    "url": "assets/AdaptiveDashboard-f8suKOqJ.js",
    "revision": null
  }, {
    "url": "assets/ActivityList-Bn4AHW1l.js",
    "revision": null
  }, {
    "url": "assets/Account360-BBmMW8d9.js",
    "revision": null
  }, {
    "url": "design-lab/assets/style.css",
    "revision": "1a858298fcba924a47a7946a1dd97850"
  }, {
    "url": "design-lab/assets/lab.css",
    "revision": "0d8e381d4668fc99adbe77d85a185c80"
  }, {
    "url": "assets/index-B1HMUtrp.css",
    "revision": null
  }, {
    "url": "index.html",
    "revision": "3e87dc4f35e1018804d6abebda49da45"
  }, {
    "url": "tools/social-selling/Pipeline Tracker.html",
    "revision": "e798dd10b33a8ebae8aff5043b955545"
  }, {
    "url": "tools/social-selling/Motor de Social Selling.html",
    "revision": "60cf9f5754c8cfe983491c7b2d9f7109"
  }, {
    "url": "tools/social-selling/Kit Campanha LinkedIn.html",
    "revision": "a90baf77ce8afeb3b78c3e3cbfe8f2d9"
  }, {
    "url": "design-lab/components-v2/index.html",
    "revision": "16dd7125fe568e0e4c49823cdbbbf5ca"
  }, {
    "url": "design-lab/command-language/index.html",
    "revision": "16dd7125fe568e0e4c49823cdbbbf5ca"
  }, {
    "url": "design-lab/assets/components-v2.html",
    "revision": "16dd7125fe568e0e4c49823cdbbbf5ca"
  }, {
    "url": "design-lab/assets/command-language.html",
    "revision": "16dd7125fe568e0e4c49823cdbbbf5ca"
  }, {
    "url": "q2.png",
    "revision": "097047560daa71aaeca42e40914f69c4"
  }, {
    "url": "q1.png",
    "revision": "ee436a48aeb17adf9acdc6791475587b"
  }, {
    "url": "brand/birthhub360-simbolo.svg",
    "revision": "a3d9d0061057999b5cfaf8007ebccd5c"
  }, {
    "url": "brand/birthhub360-logo-horizontal.svg",
    "revision": "67c3585b9c9e39827fb5825ca9f03188"
  }, {
    "url": "brand/birthhub360-icone.svg",
    "revision": "3c337447b4482f7ce1ac4b7d7eb90f65"
  }, {
    "url": "fonts/sora-latin.woff2",
    "revision": "0d0e5e4d2f9fef29f3aff5e8e0e659c4"
  }, {
    "url": "fonts/sora-latin-ext.woff2",
    "revision": "adf7c421da627d76b3b119bf52695919"
  }, {
    "url": "fonts/plus-jakarta-sans-latin.woff2",
    "revision": "7660bd9909fb097989b19471a75f1b7a"
  }, {
    "url": "fonts/plus-jakarta-sans-latin-ext.woff2",
    "revision": "341687eeeb6afd29502e2277d9762c7e"
  }, {
    "url": "fonts/inter-latin.woff2",
    "revision": "260c81a4759baf163c025001c4f27872"
  }, {
    "url": "fonts/inter-latin-ext.woff2",
    "revision": "1ad231aac0a8a891b8374aa5526a5813"
  }, {
    "url": "fonts/bodoni-moda-latin.woff2",
    "revision": "0492c86153615ad16cfd36af4eca123a"
  }, {
    "url": "fonts/bodoni-moda-latin-ext.woff2",
    "revision": "2f380b117ee0fa43449b97375c54a869"
  }, {
    "url": "manifest.webmanifest",
    "revision": "6b53b18c4450df8e5f25cffde682c609"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api\//, /^\/webhook\//]
  }));
  workbox.registerRoute(/^https?:\/\/.*\/api\/(companies|contacts|deals|activities)/, new workbox.StaleWhileRevalidate({
    "cacheName": "atlas-crm-data",
    plugins: [new workbox.ExpirationPlugin({
      maxAgeSeconds: 300,
      maxEntries: 200
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/\.(woff2?|ttf|otf|eot)$/, new workbox.CacheFirst({
    "cacheName": "atlas-fonts",
    plugins: [new workbox.ExpirationPlugin({
      maxAgeSeconds: 31536000
    })]
  }), 'GET');

}));
